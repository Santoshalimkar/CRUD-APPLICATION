import React from "react";
import { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";

import {
  Box,
  Container,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
} from "@mui/material";
import "./View.css";
import { width } from "@mui/system";

const Viewone = () => {
  const [user, setUser] = useState([]);
  const { id } = useParams();

  useEffect(() => {
    loaduser();
  }, []);

  const loaduser = async () => {
    const response = await getUser(id);
    setUser(response.data.student);
  };

  const getUser = async (id) => {
    // const URL="http://localhost:8000/api"
    try {
      return await axios.get(`http://localhost:8000/api/${id}`);
    } catch (error) {
      console.log("this is error", error);
    }
  };

  return (
    <Container maxWidth="sm">
      <Box sx={{ bgcolor: "#fff" }}>
        <div className="view-container">
          <h3>Student Details</h3>
          <div className="student-list"></div>
            <TableHead style={{backgroundColor:"#152536",color:"whitesmoke"}}>
              <TableRow >
                <TableCell style={{color:"whitesmoke"}}>Roll NO</TableCell>
                <TableCell style={{color:"whitesmoke", width:"50%" }} align="center">Name</TableCell>
                <TableCell style={{color:"whitesmoke", width:"50%"}} align="center">Address</TableCell>
                <TableCell style={{color:"whitesmoke", width:"100%"}} align="center"> DOB</TableCell>
                <TableCell style={{color:"whitesmoke"}} align="center">Stream</TableCell>
                <TableCell  style={{color:"whitesmoke"}} align="center">Gender</TableCell>
              </TableRow>
            </TableHead>
          {user.map((student, index) => 
            
            (<TableBody>
              <TableRow key={index}>
                <TableCell align="center">{student.studRno}</TableCell>
                <TableCell align="center">{student.studname}</TableCell>
                <TableCell align="center">{student.studaddress}</TableCell>
                <TableCell align="center">{student.studDOB}</TableCell>
                <TableCell align="center">{student.studstream}</TableCell>
                <TableCell align="center">{student.studgender}</TableCell>
              </TableRow>
            </TableBody>)
          )}
        </div>
      </Box>
    </Container>
  );
};

export default Viewone;
