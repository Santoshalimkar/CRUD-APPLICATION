import {
  Box,
  Container,
  List,
  ListItemButton,
  ListItem,
  ListItemText,
  ListItemIcon,
} from "@mui/material";
import React, { useState, useEffect } from "react";
import Avatar from "@mui/material/Avatar";
import axios from "axios";
import {LinkComponent,Link} from 'react-router-dom'
import RemoveRedEyeIcon from "@mui/icons-material/RemoveRedEye";

import "./View.css";

const View = () => {
  const [studdata, setstuddata] = useState([]);

  useEffect(() => {
    axios
      .get("http://localhost:8000/api/Retrive")
      .then((res) => setstuddata(res.data.student))
      .then((error) => console.log(error));
  }, []);

  return (
    <Container maxWidth="sm">
      <Box sx={{ bgcolor: "#fff" }}>
        <div className="view-container">
          <h3>View Student Details</h3>
          <div className="student-list">
          {studdata.length===0?
          <list>
          <ListItem>
            <ListItemText sx={{textAlign:"center"}} primary="Student Details Not available">

            </ListItemText>
          </ListItem>
          </list>
          :
            <List>
              {studdata.map((student, index) => (
                <ListItem key={index} disablePadding>
                  <ListItemButton>
                    <ListItemIcon>
                      <Avatar src="/broken-image.jpg" />
                    </ListItemIcon>
                    <ListItemText primary={student.studname} />
                    <ListItemIcon>
                    <Link to={`/Viewone/${student._id}`} >
                    <RemoveRedEyeIcon sx={{ color: "#152536" }} />

                    </Link>
                    </ListItemIcon>
                  </ListItemButton>
                </ListItem>
              ))}
            </List>
          }
          </div>
        </div>
      </Box>
    </Container>
  );
};

export default View;
