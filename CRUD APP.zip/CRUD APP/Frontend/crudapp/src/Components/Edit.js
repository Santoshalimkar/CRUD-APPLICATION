import React, { useState ,useEffect} from "react";
import { Container, Box } from "@mui/material";
import 'react-toastify/dist/ReactToastify.css';
import Button from "@mui/material/Button";
import axios from "axios";
import { useParams,Link } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';






const Edit = () => {
    
    const [user, setUser] = useState([]);
    const { id } = useParams();
    
  
    useEffect(() => {
      loaduser();
    }, []);
  
    const loaduser = async () => {
      const response = await getUser(id);
      setUser(response.data.student[0]);
    };
  
    const getUser = async (id) => {
      // const URL="http://localhost:8000/api"
      try {
        return await axios.get(`http://localhost:8000/api/${id}`);
      } catch (error) {
        console.log("this is error", error);
      }
    };
    console.log(user.studDOB)

    const onValueChange=(e)=>{
      setUser({...user,[e.target.name]:e.target.value})
    }
   console.log(user)

   useEffect(() => {
    adddata();
  }, []);


   

      async function adddata(e) {
        e.preventDefault()

        const response = await fetch(`http://localhost:8000/edit/${id}`, {
          method: "POST",
          headers: {
            "content-type": "application/json",
          },
    
          body: JSON.stringify({
            user,

          }),
        });

        const data = await response.json();
        console.log(data)

        if (data.status === "ok") {
          // alert("ok")
          toast.error("something wrong", {
            position: "top-center",
            autoClose: 1000,
            hideProgressBar: true,
            closeOnClick: false,
            pauseOnHover: false,
            draggable: false,
            progress: undefined,
            theme: "colored",
          });
        } else {
          // alert('error')
          toast.success("updated !", {
            position: "top-center",
            autoClose: 1000,
            hideProgressBar: true,
            closeOnClick: false,
            pauseOnHover: false,
            draggable: false,
            progress: undefined,
            theme: "colored",
            
          });
        }


    }

    

    

  return (
    <>
      <Container maxWidth="sm">
        <Box sx={{ bgcolor: "#fff"}}>
          <div className="form-container">
            <h3>Edit Student Details </h3>
            <div className="input-field">
            <form onSubmit={adddata}>
                <label className="label">Student Roll No :</label>
                <input
                  type="text"
                  name="studRno"
                  value={user.studRno}
                  onChange={(e)=>onValueChange(e) }
                />
                <label className="label">Student Name:</label>
                <input
                  type="text"
                  name="studname"

                  value={user.studname}
                  onChange={(e)=>onValueChange(e) }
                />
                <label className="label">Student Address :</label>
                <input
                  type="textarea"
                  name="studaddress"

                  value={user.studaddress}
                  onChange={(e)=>onValueChange(e)}

                />
                <label className="label" htmlFor="stream">
                  Stream:
                </label>
                <select
                  id="stream"
                  name="studstream"

                  value={user.studstream}
                  onChange={(e)=>onValueChange(e)}

                >
                  <option></option>
                  <option>BSC</option>
                  <option>BCA</option>
                </select>
                <label className="label">Student DOB :</label>
                <input
                  type="date"
                  name="studDOB"

                  value={user.studDOB}
                  onChange={(e)=>onValueChange(e)}

                  
                />
                <label className="label">Student gender :</label>
                <input
                  type="radio"
                  name="studgender"

                  value={user.studgender}
                  id="male"
                  onChange={(e)=>onValueChange(e)}

                />
                <label htmlFor="male">Male</label>
                <input
                  type="radio"
                  name="studgender"
                  value={user.studgender}
                  id="female"
                  onChange={(e)=>onValueChange(e)}

                />
                <label htmlFor="female">Female</label>
                <div className="button">
                  <Button
                  // LinkComponent={Link} to={"/View"} 
                    className="button"
                    type="submit"
                    value="submit"
                    variant="contained"
                    style={{
                      marginTop: "10px",
                      backgroundColor: "#152536",
                      marginLeft: "52px",
                    }}
                  >
                    Save
                  </Button>
                </div>
              </form>
            </div>
          </div>
        </Box>
      </Container>
      <ToastContainer
        position="top-center"
        autoClose={1000}
        hideProgressBar
        newestOnTop={false}
        closeOnClick={false}
        rtl={false}
        pauseOnFocusLoss={false}
        draggable={false}
        pauseOnHover={false}
        theme="colored"/>
      
      
    </>
  );
};

export default Edit;
