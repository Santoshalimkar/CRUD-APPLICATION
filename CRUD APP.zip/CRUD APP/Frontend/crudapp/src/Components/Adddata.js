import React, { useState } from "react";
import Container from "@mui/material/Container";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import { ToastContainer, toast } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';


import "./Adddata.css";

function Adddata() {
  const [studname, setstudname] = useState("");
  const [studRno, setstudRno] = useState("");
  const [studaddress, setstudaddress] = useState("");
  const [studstream, setstudstream] = useState("");
  const [studDOB, setstudDOB] = useState("");
  const [studgender, setstudgender] = useState("");

  async function adddata(e) {
    e.preventDefault();
    const response = await fetch("http://localhost:8000/api/adddata", {
      method: "POST",
      headers: {
        "content-type": "application/json",
      },

      body: JSON.stringify({
        studRno,
        studDOB,
        studaddress,
        studstream,
        studname,
        studgender,
      }),
    });
    const data = await response.json();
    // console.log(data.status);

    if (data.status === "ok") {
      // alert("ok")
      toast.success("Successfully Added", {
        position: "top-center",
        autoClose: 1000,
        hideProgressBar: true,
        closeOnClick: false,
        pauseOnHover: false,
        draggable: false,
        progress: undefined,
        theme: "colored",
      });
    } else {
      // alert('error')
      toast.error("Please try Again !", {
        position: "top-center",
        autoClose: 1000,
        hideProgressBar: true,
        closeOnClick: false,
        pauseOnHover: false,
        draggable: false,
        progress: undefined,
        theme: "colored",
      });
    }
  }
  return (
    <>
      <Container maxWidth="sm">
        <Box sx={{ bgcolor: "#fff" }}>
          <div className="form-container">
            <h3>Add Student Details </h3>
            <div className="input-field">
              <form onSubmit={adddata}>
                <label className="label">Student Roll No :</label>
                <input
                  type="text"
                  value={studRno}
                  onChange={(e) => {
                    setstudRno(e.target.value);
                  }}
                />
                <label className="label">Student Name:</label>
                <input
                  type="text"
                  value={studname}
                  onChange={(e) => {
                    setstudname(e.target.value);
                  }}
                />
                <label className="label">Student Address :</label>
                <input
                  type="textarea"
                  value={studaddress}
                  onChange={(e) => {
                    setstudaddress(e.target.value);
                  }}
                />
                <label className="label" htmlFor="stream">
                  Stream:
                </label>
                <select
                  id="stream"
                  name="strem"
                  value={studstream}
                  onChange={(e) => {
                    setstudstream(e.target.value);
                  }}
                >
                  <option></option>
                  <option>BSC</option>
                  <option>BCA</option>
                </select>
                <label className="label">Student DOB :</label>
                <input
                  type="date"
                  value={studDOB}
                  onChange={(e) => {
                    setstudDOB(e.target.value);
                  }}
                />
                <label className="label">Student gender :</label>
                <input
                  type="radio"
                  value="Male"
                  id="male"
                  name="male"
                  onChange={(e) => {
                    setstudgender(e.target.value);
                  }}
                />
                <label htmlFor="male">Male</label>
                <input
                  type="radio"
                  value="Female"
                  id="female"
                  name="female"
                  onChange={(e) => {
                    setstudgender(e.target.value);
                  }}
                />
                <label htmlFor="female">Female</label>
                <div className="button">
                  <Button
                    className="button"
                    type="submit"
                    value="submit"
                    variant="contained"
                    style={{
                      marginTop: "10px",
                      backgroundColor: "#152536",
                      marginLeft: "52px",
                    }}
                  >
                    Add
                  </Button>
                </div>
              </form>
            </div>
          </div>
        </Box>
      </Container>
      <ToastContainer
        position="top-center"
        autoClose={1000}
        hideProgressBar
        newestOnTop={false}
        closeOnClick={false}
        rtl={false}
        pauseOnFocusLoss={false}
        draggable={false}
        pauseOnHover={false}
        theme="colored"
      />
    </>
  );
}

export default Adddata;
