import React, { useState, useEffect } from "react";
import "./Update.css";
import {
  Box,
  Container,
  ListItemIcon,
  List,
  ListItem,
  ListItemButton,
  ListItemText,
} from "@mui/material";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import Avatar from "@mui/material/Avatar";
import axios from "axios";
import { Link } from "react-router-dom";

const Updated = () => {
  const [studdata, setstuddata] = useState([]);

  useEffect(() => {
    axios
      .get("http://localhost:8000/api/Retrive")
      .then((res) => setstuddata(res.data.student))
      .then((error) => console.log(error));
  }, []);



  

  return (
    <Container maxWidth="sm">
      <Box sx={{ bgcolor: "#fff"}}>
        <div className="update-container">
          <h3>Update Student Details</h3>
          <div className="update-list">
            <List>
              {studdata.map((student, id) => (
                <ListItem key={id} disablePadding>
                  <ListItemButton>
                    <ListItemIcon>
                      <Avatar src="/broken-image.jpg" />
                    </ListItemIcon>
                    <ListItemText primary={student.studname} />
                    <ListItemIcon>
                   <Link to={`/Edit/${student._id}`}><EditIcon sx={{ color: "#152536" }} /></Link>   
                    </ListItemIcon>
                    <ListItemIcon>
                    <Link to={`/Delete/${student._id}`}><DeleteIcon sx={{ color: "#152536" }} /></Link>   
                    </ListItemIcon>
                  </ListItemButton>
                </ListItem>
              ))}
            </List>
          </div>
        </div>
      </Box>
    </Container>
  );
};

export default Updated;
