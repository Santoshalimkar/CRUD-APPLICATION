import React, { useState, useEffect } from "react";
import "./Update.css";
import {
  Box,
  Container,
  ListItemIcon,
  List,
  ListItem,
  ListItemButton,
  ListItemText,
} from "@mui/material";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import Avatar from "@mui/material/Avatar";
import axios from "axios";
import { Link} from "react-router-dom";

const Update = () => {
  const [studdata, setstuddata] = useState([]);
  const [status, setstatus] = useState([]);
  // const history=useNavigate();

  useEffect(() => {
    getAlluser();
  }, []);

  const getAlluser = async () => {
    await axios
      .get("http://localhost:8000/api/Retrive")
      .then((res) => setstuddata(res.data.student))
      .then((error) => console.log(error));
  };

  

    const deleteuser = async (id) => {
      await deleteStudent(id);
      getAlluser();
    };
  


  const deleteStudent = async (id) => {
    // const URL="http://localhost:8000/api"
    try {
      return await axios
        .get(`http://localhost:8000/delete/${id}`)
        .then((res) =>setstatus(res.data));
    } catch (error) {
      console.log("this is error", error);
    }

    
  };

  if(status.message==="deleted successfully"){
    // window.location.reload()
    getAlluser();
  }

  return (
    <Container maxWidth="sm">
      <Box sx={{ bgcolor: "#fff" }}>
        <div className="update-container">
          <h3>Update Student Details</h3>
          <div className="update-list">

          
          {studdata.length===0?
          <list>
          <ListItem>
            <ListItemText sx={{textAlign:"center"}} primary="Student Details Not available">

            </ListItemText>
          </ListItem>
          </list>
          :


            <List>
              {studdata.map((student, id) => (
                <ListItem key={id} disablePadding>
                  <ListItemButton>
                    <ListItemIcon>
                      <Avatar src="/broken-image.jpg" />
                    </ListItemIcon>
                    <ListItemText primary={student.studname} />
                    <ListItemIcon>
                      <Link to={`/Edit/${student._id}`}>
                        <EditIcon sx={{ color: "#152536" }} />
                      </Link>
                    </ListItemIcon>
                    <ListItemIcon>
                      <DeleteIcon
                        onClick={() => deleteuser(student._id)}
                        sx={{ color: "#152536" }}
                      />
                    </ListItemIcon>
                  </ListItemButton>
                </ListItem>
              ))}
            </List>
          
          }



          </div>
        </div>
      </Box>
    </Container>
  );
};

export default Update;
