import { Box, Container } from '@mui/material'
import SchoolIcon from '@mui/icons-material/School';
import React from 'react'
import "./Home.css"

function Home() {
  return (
    <Container maxWidth="sm">
    <Box sx={{ bgcolor: "#fff"}}>
    <div className="home-container">
     <div className="main-home">
        <h3> CRUD </h3>
     </div>
     <div className="home-title">
     <SchoolIcon sx={{height:"100px" ,width:"100px",marginTop:"100px"}}/>

     </div>
     <div className="title">
        <h2>STUDENT INFORMATION</h2>
        <p>(CRUD operations)</p>
     </div>





    </div>







    </Box>


    </Container>
  )
}

export default Home