import './App.css';
import Nav from './Components/Nav';
import BottomNav from './Components/BottomNav';
import Adddata from './Components/Adddata';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import View from './Components/View';
import Update from './Components/Update';
import Home from './Components/Home';
import Viewone from './Components/Viewone';
import Edit from './Components/Edit';
// import Updated from './Components/Updated';

function App() {
  return (
    <>
    <BrowserRouter>
    <Routes>
      <Route path='/' element={[<Nav/>,<Home/>,<BottomNav/>]}/>
      <Route path='/View' element={[<Nav/>,<View/>,<BottomNav/>]}/>
      <Route path='/Update' element={[<Nav/>,<Update/>,<BottomNav/>]}/>
      <Route path='/Home' element={[<Nav/>,<Home/>,<BottomNav/>]}/>
      <Route path='/Viewone/:id' element={[<Nav/>,<Viewone/>,<BottomNav/>]}/>
      <Route path='/Edit/:id' element={[<Nav/>,<Edit/>,<BottomNav/>]}/>
      <Route path='/Adddata' element={[<Nav/>,<Adddata/>,<BottomNav/>]}>


      </Route>
    </Routes>
    </BrowserRouter>
    

    </>
  );
}

export default App;
