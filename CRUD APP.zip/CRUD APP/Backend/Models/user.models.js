const mongoose=require('mongoose')

const studentSchema = new mongoose.Schema(
  {
    studRno: {
      type: Number,
      unique: true,
      required: true,
    },
    studname: {
      type: String,
      unique: true,
      required: true,
    },
    studaddress: {
      type: String,
      required: true,
    },
    studstream: {
      type: String,
      required: true,
    },
    studDOB: {
      type: String,
      required: true,
    },
    studgender: {
      type: String,
      required: true,
    },
  },
  {
    collection:"Student-data"
  }
);

const User = mongoose.model('studentdata', studentSchema);

module.exports=User