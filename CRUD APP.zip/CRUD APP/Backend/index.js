const express= require("express");
const mongoose=require("mongoose")
const app=express()
const cors=require('cors')
const student=require("./Models/user.models");
const { response } = require("express");
const port=8000


app.use(cors());
app.use(express.json());



mongoose.set('strictQuery',true)

const mongoDB =
  "mongodb://localhost:27017/student-crud";
mongoose.connect(mongoDB, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
  family: 4,
});

const db = mongoose.connection;
db.on("error", console.error.bind(console, "MongoDB connection error:"));


app.post("/api/adddata", async (req, res) => {
    console.log(req.body);
    try {
      await student.create({
        studRno:req.body.studRno,
        studname: req.body.studname,
        studaddress: req.body.studaddress,
        studstream: req.body.studstream,
        studDOB: req.body.studDOB,
        studgender: req.body.studgender,
      });
      res.json({ status: "ok" });
    } catch (err) {
      res.json({ status: "error", error: "duplicate data" });
    }
  });


  app.get("/api/Retrive", async (req, res) => {
    const studentdata = await student.find({}).sort({
      studRno:1,
  });;

    if(studentdata){
      return res.json({student:studentdata });
  } else {
    return res.json({student:false });
  }
});


  app.get("/api/:id", async (req, res) => {
    const studentdata = await student.find({_id:req.params.id});

    if(studentdata){
      return res.json({student:studentdata });
  } else {
    return res.json({student:false });
  }
});

//for Delete 
app.get("/delete/:id", async (req,res)=>{
  console.log(req.params.id)
  try {
     await student.deleteOne({_id:req.params.id})
     res.status(200).json({message:"deleted successfully"})

    
  } catch (error) {
    console.log("cant delete")
    
  }
}

)






//for edit api 

app.post("/edit/:id", async (req, res) => {
  const set=req.body.user;
  console.log(set)
  try {
    await student.updateOne({_id:set._id}, { $set: set}) 
    res.json({ status: "ok",res });
  } catch (err) {
    res.json({ status: "error", error: "duplicate data"});
  }
});

    




app.listen(port, () => {
    console.log(`Example app listening on port ${port}`);
  });
  